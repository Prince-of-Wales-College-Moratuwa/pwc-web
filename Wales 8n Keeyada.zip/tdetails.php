<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">


        <title>Teacher's Data</title>

        <!-- Bootstrap core CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/bootstrap-theme.css" rel="stylesheet">
        <link href="css/bootstrap-theme.min.css" rel="stylesheet">
        <link href="css/font-awesome.css" rel="stylesheet">
        <link href="css/carousel.css" rel="stylesheet">

        <script type="text/javascript" src="js/jquery.min.js"></script>
        <script type="text/javascript" src="js/bootstrap.js"></script>
<script type="text/javascript">
    $(function () {
        $("input[name='school']").click(function () {
            if ($("#chkNo").is(":checked")) {
                $("#schoolname").removeAttr("disabled");  
                $("#schooldistrict").removeAttr("disabled") ;
                $("#schoolname").focus();
                 $("#schooldistrict").focus();
            } else {
                $("#schoolname").attr("disabled", "disabled");
                $("#schooldistrict").attr("disabled", "disabled");
            }
        });
    });
</script>


    </head>
    <body>
         <div class="container">
<br>

    <!--Fullname-->
  <div class="form-group">
      <label for="firstname" class="col-sm-2 col-form-label">Full Name</label>
    <div class="col-sm-9">
        
      <input type="text" class="form-control" placeholder="Disanayake Mudiyanselage Dushan Akalanka Disanayake" name="fname" style='text-transform:uppercase' required> 
    </div>
 </div>
<br>
 
  <!--Name with Initials-->
   <div class="form-group">
        <label for="iname" class="col-sm-2 col-form-label">Name with Initials</label>
    <div class="col-sm-5">
      <input type="text" class="form-control" placeholder="D.M.D.A. Disanayake" name="iname" style='text-transform:uppercase' required>
    </div>
  </div>
<br>

   <!--Gender-->
 <div class="form-group">
    <label for="gender" class="col-sm-2">Gender</label>
    <div class="col-sm-9">
        <label class="radio-inline control-label">
            <input checked="checked" name="gender" type="radio" value="Male"> Male
        </label>
        <label class="radio-inline control-label">
            <input name="gender" type="radio" value="Female"> Female
        </label>
    </div>
</div>
<br>

 <!--Date of birth-->
 <div class="form-group">
     <label for="birthday"class="col-sm-2">Birthday</label>
      <div class="col-sm-9">
          <input type="date" id="birthday" name="birthday">
          </div>
</div>
<br>

 <!--NIC-->
  <div class="form-group">
     <label for="nic"class="col-sm-2 col-form-label ">National Idenetity Card No.</label>
      <div class="col-sm-2">
          <input type="tel"  class="form-control" id="nic"  name="nic" maxlength="12" >
          </div>
</div>
<br>

 <!--Address-->
 <div class="form-group">
    <label for="address"class="col-sm-2 col-form-label ">Personal Address</label>
     <div class="col-sm-8">
      <input type="text" class="form-control" name="address1" placeholder="Address Line 1"  required>
    </div>
</div>
 <div class="form-group">
    <label for="address"class="col-sm-2 col-form-label "></label>
    <div class="col-sm-8">
      <input type="text" class="form-control" name="address2" placeholder="Address Line 2">
      </div>
 </div>  
  <div class="form-group">
    <label for="address"class="col-sm-2 col-form-label "></label>
    <div class="col-sm-4">
      <input type="text" class="form-control" name="city" placeholder="City"  required>
    </div>
</div>
<br>

<!--Contact Number-->
<div class="form-group">
     <label for="contact"class="col-sm-2 col-form-label ">Contact No.</label>
      <div class="col-sm-2">
          <input type="text"  class="form-control" id="residential" placeholder="Residential No." name="residential" pattern="[0-9]+">
          </div>
<div class = "col-sm-1"> &nbsp;</div>
      <div class="col-sm-2">
          <input type="text"  class="form-control" id="mobile1" placeholder="Mobile 1" name="mobile1" pattern="[0-9]+">
          </div>
<div class = "col-sm-1"> &nbsp;</div>
      <div class="col-sm-2">
          <input type="textr" class="form-control" id="mobile" placeholder="Mobile 2" name="mobile2"pattern="[0-9]+">
          </div>
</div>
<br>

<!-- Email-->
<div class="form-group">
     <label for="email" class="col-sm-2 col-form-label ">Email address (if any)</label>
      <div class="col-sm-4">
    <input type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter email" name="email" >
    </div>
    
</div>
<br>   

<!--educational-->
          <div class="col-sm-3">
            <label for="in_ex">  Highest Educational Qualifications </label>
            </div>
      <div class="col-sm-3">
          <select id = "Qualifications" name="Qualifications" style="min-height:30px;">
          <option value="Art Degree(english as a main subject) " > Art Degree(english as a main subject)</option>
          <option value="Art Degree(other than the above)" > Art Degree(other than the above) </option>
          <option value="Bauddha Dharmacharya Examination" > Bauddha Dharmacharya Examination </option>
           <option value="BED" > BED </option>
           <option value="Commerce degree or equal diploma" > Commerce degree or equal diploma </option>
           <option value="Dancing-Art/Performaing Art/Aesthetic Degree or Equal Diploma">Dancing-Art/Performaing Art/Aesthetic Degree or Equal Diploma</option>
           <option value="GCE-AL or Equal"> GCE-AL or Equal</option>
           <option value="GCE-OL or Equal"> GCE-OL or Equal</option>
           <option value="Higher National Diploma in Accountancy">Higher National Diploma in Accountancy</option>
           <option value="Master Degree(MA,MSc,Med)">Master Degree(MA,MSc,Med)</optoon>
           <option value="NCE Traning">NCE Traning</option>
           <option value="NCOE Diploma(Vidyapeeta)">NCOE Diploma(Vidyapeeta)</option> 
           <option value="Other Fist Digree or Equal(BA,BSc,Bcom,Bed..)">Other Fist Digree or Equal(BA,BSc,Bcom,Bed..)</option>
           <option value="Performing Aot-Aot Perfooming Aot/Aesthetic Digree or Equal Diploma">Performing Aot-Aot Perfooming Aot/Aesthetic Digree or Equal Diploma</option>
           <option value="PGDE">PGDE</option>
           <option value="Preliminary Privena Final Examination">Preliminary Privena Final Examination</option>
           <option value="Science Degree(Physic)">Science Degree(Physic)</option>
           <option value="Science Degree(zoology)">Science Degree(zoology)</option>
           <option value="Science Degree(IT)">Science Degree(IT)</option>
           <option value="Science Degree(Other Fields)">Science Degree(Other Fields)</option>
           <option value="Teacher Traning Ctificate-distance">Teacher Traning Ctificate-distance</option>
           <option value="teacher traning cetificate-institutional">teacher traning cetificate-institutional</option>
      </select> </div>
</div> 
<br>

<!--child's deta-->
<div class="form-group">
    <label for="child"class="col-sm-2 col-form-label ">Child's Data</label>
     <div class="col-sm-8">
      <input type="text" class="form-control" name="Child1" placeholder="Child Name 1"  required>
    </div>
</div>
 <div class="form-group">
    <label for="child"class="col-sm-2 col-form-label "></label>
    <div class="col-sm-8">
      <input type="text" class="form-control" name="child2" placeholder="Child Name 2">
      </div>
 </div>  
  <div class="form-group">
    <label for="Child"class="col-sm-2 col-form-label "></label>
    <div class="col-sm-4">
      <input type="text" class="form-control" name="child3" placeholder="Child Name 3"  required>
    </div>
</div>
<br>

<div class="form-group">
     <label for="ServiceName" class="col-sm-2 col-form-label ">ServiceName
     </label>
      <div class="col-sm-4">
    <input type="ServiceName" class="form-control" id="ServiceName" aria-describedby="emailHelp" placeholder="Enter ServiceName" name="ServiceName" >
    </div>
    <br>
<!--
 <div class="col-sm-3">
                    <label for="in_ex"> Description </label>
                </div>
                <div class="col-sm-3">
                    <select id="transport" name="Description" style="min-height:30px;">
                        <option value="Transferred"> Transferred  </option>
                        <option value="New (First) Appointment"> New (First) Appointment </option>
                        <option value="Promotion"> Promotion </option>
                        <option value="Walk"> Walk </option>
                        <option value="Else"> Else </option>
                    </select> </div>
            </div>-->

<div class="form-group col-12">
            
 
    <div class="form-group"></div>
     <div class="form-group"></div>
     <div class="form-group">
     <div class = "col-sm-12">
    <button type="reset" name = "reset" value="Clear" class="btn btn-primary btn-sm" > Reset </button>
    <button type="submit" name = "submit" class="btn btn-success btn-sm">Submit</button>
    <button type="cancel" name="cancel" onclick="window.location.replace('../OL.html')" value="Cancel" class="btn btn-primary btn-sm"/> Cancel </button>
  </div>
  </div> 
   
   </form>
  

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script type="text/javascript" src="http://arrow.scrolltotop.com/arrow5.js"></script>
<noscript>Not seeing a <a href="http://www.scrolltotop.com/">Scroll to Top Button</a>? Go to our FAQ page for more info.</noscript>

    </body>
</html>