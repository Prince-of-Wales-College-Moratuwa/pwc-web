<?php 

//action.php

include '../database_connection.php';

?>